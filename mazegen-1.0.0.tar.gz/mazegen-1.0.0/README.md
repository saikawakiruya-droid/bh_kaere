*This project has been created as part of the 42 curriculum by &lt;login&gt;.*

# A-Maze-ing — This is the way

独自の迷路ジェネレータです。設定ファイルを受け取り、（必要なら完全な）迷路を
生成し、16 進の壁表現でファイルに書き出します。ターミナルへの ASCII 描画と、
生成結果が条件を満たすか検証する専用バリデータを備えます。

> ⚠️ 1 行目の `<login>` は提出前に自分の 42 ログインへ置き換えてください。

---

## Description（概要）

- 設定ファイル（`KEY=VALUE`）を読み込み、迷路を生成します。
- 迷路の中央には、複数の完全に閉じたセルで描かれた **「42」** が浮かび上がります。
- `PERFECT=True` の場合、入口・出口間の経路はちょうど 1 本（全域木）です。
- 生成後に条件（連結性・壁整合・外周・3x3 開放禁止・最短経路など）を自動検証します。
- 出力ファイルは仕様の 16 進形式で、同梱バリデータや Moulinette で検証できます。

---

## Instructions（インストール・実行）

### 依存関係

実行に必要な外部ライブラリはありません（標準ライブラリのみ）。開発用に
`flake8` / `mypy` / `pytest` を使います。

### セットアップと実行

```bash
# 依存ツールのインストール（grading 環境）
make install

# 迷路を生成して表示（既定の config.txt を使用）
make run

# 別の設定ファイルを指定
make run CONFIG=my_config.txt

# デバッグ実行（pdb）
make debug

# テスト
make test

# 静的チェック（flake8 + mypy）
make lint
```

直接実行する場合:

```bash
python3 a_maze_ing.py config.txt
```

> 補足: このリポジトリの開発環境ではシステムの `python` が壊れていたため、
> `uv` で仮想環境を作成しています。ローカルで動かす場合は
> `uv venv .venv && uv pip install --python .venv flake8 mypy pytest` の後、
> `make run PYTHON=.venv/Scripts/python.exe`（Windows）のように Python を
> 上書きできます。

### 出力ファイルの検証

```bash
python3 validator.py maze.txt
```

---

## 設定ファイルの構造とフォーマット

1 行に 1 つの `KEY=VALUE`。`#` で始まる行と空行は無視されます。

### 必須キー

| キー | 説明 | 例 |
|------|------|-----|
| `WIDTH` | 迷路の幅（セル数、1 以上） | `WIDTH=25` |
| `HEIGHT` | 迷路の高さ（セル数、1 以上） | `HEIGHT=20` |
| `ENTRY` | 入口座標 `x,y` | `ENTRY=0,0` |
| `EXIT` | 出口座標 `x,y`（入口と異なる） | `EXIT=24,19` |
| `OUTPUT_FILE` | 出力ファイル名 | `OUTPUT_FILE=maze.txt` |
| `PERFECT` | 完全迷路にするか（`True`/`False`） | `PERFECT=True` |

### 任意キー（`options.py` が処理）

| キー | 説明 | 既定値 |
|------|------|--------|
| `SEED` | 乱数シード（再現性） | なし（毎回ランダム） |
| `ALGORITHM` | 生成アルゴリズム名 | `backtracker` |
| `DISPLAY` | 表示モード名 | `ascii` |
| `SIGN` | 埋め込む文字列 | `42` |
| `SCALE` | サインの拡大倍率 | `1` |

不正な値はキーごとに区別されたエラー（`ConfigParseError` / `ConfigKeyError` /
`ConfigValueError`）になり、明確なメッセージを表示して終了します。

---

## 出力ファイルの形式（仕様 IV.5）

- 各セルを 1 桁の大文字 16 進で表します。閉じている壁をビット化:
  `bit0=北, bit1=東, bit2=南, bit3=西`（閉じていれば 1）。
- セルは行ごとに 1 行ずつ。
- 空行を 1 つ挟み、続けて 3 行: 入口座標 `x,y` / 出口座標 `x,y` /
  最短経路（`N`/`E`/`S`/`W` の連結）。
- すべての行は `\n` で終わります。

---

## 採用アルゴリズムと選定理由

### 生成: 再帰バックトラッカー（反復版）

全セルを壁で閉じた状態から、深さ優先でランダムに掘り進み、行き止まりで
スタックを戻ります。これは全セルを 1 本の木（**全域木**）に繋ぐため、
`PERFECT=True`（任意の 2 点間に経路 1 本）を自然に満たします。

**選定理由:**

- 完全迷路を保証する（DFS 木 = 全域木）。
- 実装が単純で、乱数源 1 つ（`random.Random(seed)`）に集約でき再現性が高い。
- 明示スタックの反復実装にしたため、大きな迷路でも Python の再帰上限に
  達しません。
- 「42」の予約セルを掘らないだけで、サインを通路の中に残せます。

アルゴリズムは `ALGORITHM` キーで選択でき（現状は `backtracker` のみ）、
将来 Prim 法・Kruskal 法などを `generator.py` の `ALGORITHMS` に登録すれば
そのまま選べる設計です。

### 解探索: BFS（幅優先探索）

入口・出口それぞれから各セルへの最短距離を求め、最短経路（および経路上の
全セル）を取得します。BFS なので不完全迷路でも最短性を保証します。

---

## 生成後の検証（`validator.py`）

専用バリデータが、生成された迷路が仕様 IV.4 の条件を満たすか確認します:

- 入口・出口が範囲内で互いに異なる
- 外周セルの外向き壁が閉じている
- 隣接セルが壁を整合して共有している
- 「42」（`0xF` の閉セル）以外の全セルが連結している
- 3x3 の完全開放領域がない（通路は最大 2 セル幅）
- `PERFECT` 指定時、経路がちょうど 1 本（閉路なし）
- 付随する最短経路が実際に歩けて最短

メインプログラムは生成直後にこの検証を実行し、問題があれば警告します。
ライブラリ（`validate()`）としても、CLI（`python3 validator.py <file>`）
としても使えます。

---

## 再利用可能なコードと使い方

迷路生成・探索・壁表現はモジュールとして再利用できます。

```python
import random
from maze import Maze, solve, solution_cells
from generator import generate_backtracker
from initializer import reserved_cells

# 「42」予約セルを確保して迷路を生成
reserved = reserved_cells(25, 20)
maze = generate_backtracker(25, 20, reserved, random.Random(42), start=(0, 0))

# 解（最短経路）を取得
path = solve(maze, (0, 0), (24, 19))          # 例: "EESS..."
cells = solution_cells(maze, (0, 0), (24, 19)) # 経路上のセル集合

# 壁コードへのアクセス（bit0=N,1=E,2=S,3=W、閉=1）
code = maze.cells[0][0]
```

主なモジュール:

- `maze.py` — 壁表現（`Maze`）、`open_wall`、`bfs_distances`、`solve`、`solution_cells`
- `initializer.py` — 初期マップ生成と「42」サインの配置
- `generator.py` — 生成アルゴリズムと選択レジストリ
- `display.py` — ASCII 描画と表示モードレジストリ
- `validator.py` — 条件検証

> 単一ファイルの `pip` パッケージ（`mazegen-*`）化は今後の作業です。

---

## チームとプロジェクト管理

- **メンバーと役割:** （記入してください）
- **計画と進化:** 「探索 → 初期化(42) → 生成 → 出力 → 表示 → 検証」の順に、
  各機能を小さくコミットしながら段階的に構築しました。
- **うまくいったこと:** 壁表現を 1 か所（`maze.py`）に集約したことで、生成・
  表示・出力・検証の間で齟齬が出ませんでした。例外を致命/非致命で階層化し、
  エラーを区別しやすくしました。
- **改善できること:** `PERFECT=False` の braiding、通路 2 セル幅化の後処理、
  MLX 表示、パッケージ化が残課題です。

---

## Resources（参考資料・AI 利用）

- 迷路生成アルゴリズム（再帰バックトラッカー / Prim / Kruskal）の一般的解説
- グラフ理論の全域木と完全迷路の対応
- 「42」サインの正確な形状は課題 PDF（`a_maze_ing.pdf`）の図から採取

**AI の利用:** 設計の壁打ち、各モジュールの実装・docstring・型注釈、テスト作成、
PDF からの「42」形状抽出（画像解析）、README 整備に AI を利用しました。
