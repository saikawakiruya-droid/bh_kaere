"""mazegen — 再利用可能な迷路生成モジュール（単一ファイル）。

将来のプロジェクトから ``pip install`` して使える、自己完結した迷路
ジェネレータ。本体プロジェクト（A-Maze-ing）の他ファイルには依存しない。

セルは 4 ビットで壁を表す（閉じている壁のビットが 1）::

    bit0 = 北(N), bit1 = 東(E), bit2 = 南(S), bit3 = 西(W)

基本的な使い方::

    from mazegen import MazeGenerator

    # 12x8 の完全迷路を seed 指定で生成
    gen = MazeGenerator(12, 8, seed=42)
    gen.generate()

    # 生成構造（壁コードの 2 次元配列）へアクセス
    grid = gen.grid
    code = gen.wall_code(0, 0)

    # 少なくとも 1 つの解（入口→出口の最短経路）を取得
    path = gen.solution((0, 0), (11, 7))        # 例 "EESSE..."
    cells = gen.solution_cells((0, 0), (11, 7))  # 経路上のセル集合

    # 不完全迷路（ループあり）にする
    gen2 = MazeGenerator(20, 15, seed=1, perfect=False).generate()
"""

from __future__ import annotations

import random
from collections import deque
from typing import Dict, List, Optional, Set, Tuple

__version__ = "1.0.0"
__all__ = ["MazeGenerator"]

Coord = Tuple[int, int]

WALL_N = 1 << 0
WALL_E = 1 << 1
WALL_S = 1 << 2
WALL_W = 1 << 3

# 方向 -> (dx, dy, 壁ビット)
_DIRS: Dict[str, Tuple[int, int, int]] = {
    "N": (0, -1, WALL_N),
    "E": (1, 0, WALL_E),
    "S": (0, 1, WALL_S),
    "W": (-1, 0, WALL_W),
}
_OPP = {"N": "S", "S": "N", "E": "W", "W": "E"}


class MazeGenerator:
    """迷路を生成し、その構造と解へのアクセスを提供するクラス。

    Attributes:
        width: 幅（セル数）。
        height: 高さ（セル数）。
        seed: 乱数シード（再現性）。``None`` なら毎回ランダム。
        perfect: ``True`` で完全迷路（全域木）、``False`` でループを含む。
        grid: ``grid[y][x]`` に各セルの 4 ビット壁コード（生成後に有効）。
    """

    def __init__(self, width: int, height: int, seed: Optional[int] = None,
                 perfect: bool = True) -> None:
        if width <= 0 or height <= 0:
            raise ValueError("width と height は正の整数である必要があります")
        self.width = width
        self.height = height
        self.seed = seed
        self.perfect = perfect
        self._rng = random.Random(seed)
        # 既定では全セル四方とも壁あり。
        self.grid: List[List[int]] = [
            [0xF for _ in range(width)] for _ in range(height)
        ]

    # --- 内部ヘルパー -----------------------------------------------------
    def _in_bounds(self, x: int, y: int) -> bool:
        return 0 <= x < self.width and 0 <= y < self.height

    def _is_open(self, x: int, y: int, direction: str) -> bool:
        _, _, bit = _DIRS[direction]
        if self.grid[y][x] & bit:
            return False
        dx, dy, _ = _DIRS[direction]
        return self._in_bounds(x + dx, y + dy)

    def _open(self, x: int, y: int, direction: str) -> None:
        dx, dy, bit = _DIRS[direction]
        nx, ny = x + dx, y + dy
        _, _, obit = _DIRS[_OPP[direction]]
        self.grid[y][x] &= ~bit
        self.grid[ny][nx] &= ~obit

    def _openings(self, x: int, y: int) -> int:
        return sum(1 for d in _DIRS if self._is_open(x, y, d))

    # --- 生成 -------------------------------------------------------------
    def generate(self, start: Optional[Coord] = None) -> "MazeGenerator":
        """反復版・再帰バックトラッカーで迷路を生成する。

        ``perfect=False`` の場合は生成後に行き止まりを減らしてループを作る。

        Args:
            start: 掘り始めるセル。``None`` なら ``(0, 0)``。

        Returns:
            自身（メソッドチェーン用）。
        """
        # 毎回同じ結果になるよう乱数源をリセットする。
        self._rng = random.Random(self.seed)
        self.grid = [[0xF for _ in range(self.width)]
                     for _ in range(self.height)]

        sx, sy = start if start is not None else (0, 0)
        visited: Set[Coord] = {(sx, sy)}
        stack: List[Coord] = [(sx, sy)]
        total = self.width * self.height
        while len(visited) < total:
            x, y = stack[-1]
            nbrs = []
            for d, (dx, dy, _) in _DIRS.items():
                n = (x + dx, y + dy)
                if self._in_bounds(*n) and n not in visited:
                    nbrs.append((d, n))
            if nbrs:
                d, n = self._rng.choice(nbrs)
                self._open(x, y, d)
                visited.add(n)
                stack.append(n)
            else:
                stack.pop()

        if not self.perfect:
            self._braid()
        return self

    def _braid(self, ratio: float = 1.0) -> None:
        """行き止まりを減らしてループを作る（不完全迷路化）。"""
        dead = [(x, y) for y in range(self.height) for x in range(self.width)
                if self._openings(x, y) == 1]
        self._rng.shuffle(dead)
        for (x, y) in dead[:int(len(dead) * ratio)]:
            if self._openings(x, y) != 1:
                continue
            cands = [d for d, (dx, dy, bit) in _DIRS.items()
                     if self._in_bounds(x + dx, y + dy)
                     and self.grid[y][x] & bit]
            if cands:
                self._open(x, y, self._rng.choice(cands))

    # --- 構造アクセス -----------------------------------------------------
    def wall_code(self, x: int, y: int) -> int:
        """セル ``(x, y)`` の 4 ビット壁コードを返す。"""
        if not self._in_bounds(x, y):
            raise ValueError(f"範囲外: ({x},{y})")
        return self.grid[y][x]

    # --- 解 ---------------------------------------------------------------
    def _distances(self, source: Coord) -> Dict[Coord, int]:
        dist: Dict[Coord, int] = {source: 0}
        q: deque[Coord] = deque([source])
        while q:
            x, y = q.popleft()
            for d, (dx, dy, _) in _DIRS.items():
                if not self._is_open(x, y, d):
                    continue
                n = (x + dx, y + dy)
                if n not in dist:
                    dist[n] = dist[(x, y)] + 1
                    q.append(n)
        return dist

    def solution(self, entry: Coord, exit_: Coord) -> Optional[str]:
        """入口から出口への最短経路を ``N``/``E``/``S``/``W`` で返す。

        到達不能なら ``None``、入口=出口なら空文字列。
        """
        if not self._in_bounds(*entry) or not self._in_bounds(*exit_):
            raise ValueError("entry/exit が範囲外です")
        if entry == exit_:
            return ""
        d_exit = self._distances(exit_)
        if entry not in d_exit:
            return None
        steps: List[str] = []
        x, y = entry
        while (x, y) != exit_:
            remaining = d_exit[(x, y)]
            for d, (dx, dy, _) in _DIRS.items():
                if self._is_open(x, y, d) and \
                        d_exit.get((x + dx, y + dy)) == remaining - 1:
                    steps.append(d)
                    x, y = x + dx, y + dy
                    break
        return "".join(steps)

    def solution_cells(self, entry: Coord, exit_: Coord) -> Set[Coord]:
        """最短経路上のセル集合を返す（到達不能なら空集合）。"""
        d_entry = self._distances(entry)
        d_exit = self._distances(exit_)
        if exit_ not in d_entry:
            return set()
        best = d_entry[exit_]
        return {c for c, de in d_entry.items()
                if c in d_exit and de + d_exit[c] == best}
