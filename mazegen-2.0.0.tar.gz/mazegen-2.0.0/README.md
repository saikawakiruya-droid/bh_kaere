*This project has been created as part of the 42 curriculum by naarai, ksadayas.*

# A-Maze-ing — This is the way

カスタム迷路ジェネレーターです。設定ファイルを読み込み、（必要に応じて完全迷路を）生成し、壁情報を 16 進数で表したファイルへ書き出します。ターミナルでの ASCII 表示機能と、生成結果が各条件を満たすか検査する専用バリデーターも備えています。

---

## 概要（Description）

- 設定ファイル（`KEY=VALUE` 形式）を読み込み、迷路を生成します。
- 迷路の中央には、完全に閉じた複数のセルで描かれた **「42」** が現れます。
- `PERFECT=True` の場合、入口と出口の間には経路がちょうど 1 つだけ存在します（全域木＝完全迷路）。
- `PERFECT=False` の場合は、**Pac-Man をプレイ可能な盤面**（仕様 IV.4, v2.2）に変換します。プレイヤーが追い詰められないよう、四隅と中央を通路（開口 2 つ以上）として開き、独立ループを 2 本以上張り、行き止まりを僅少に抑えます。これが本課題のデフォルト（非完全迷路）の狙いです。
- 生成後に、各条件（連結性、壁の整合性、外周、3×3 の開放領域がないこと、最短経路など）を自動検証します。
- 出力ファイルは課題仕様の 16 進形式で、同梱バリデーターで検査できます。

---

## ファイル構成

迷路パイプラインは役割ごとの小さなパッケージに分割されており、各モジュールは単独でインポートできます。**入力検証**（迷路を組む前に設定ファイルの入力を検査＝`validation/`）と、**構造検証**（組み上がった迷路の構造を検査＝`verification/`）は別プロセスである点に注意してください。

| パス | 役割 |
|------|------|
| `a_maze_ing.py` | メインプログラム（エントリーポイント） |
| `core/maze.py` | コア機能（壁の表現、開閉、BFS 距離、最短経路） |
| `core/metrics.py` | ループ数・行き止まり数の計数（`braiding/` と `verification/` が共有） |
| `core/errors.py` | 例外クラスの階層 |
| `validation/config.py` / `validation/options.py` | 必須キーの検証／任意キーの処理 |
| `generation/initializer.py` | 初期マップの生成と「42」記号の配置 |
| `generation/backtracker.py` | 再帰的バックトラッカー本体 |
| `generation/generator.py` | 生成アルゴリズムの選択用レジストリ |
| `braiding/braiding.py` | 不完全迷路（プレイアブル盤面）への変換（`PERFECT=False`） |
| `verification/verifier.py` | 生成後の条件検証（ライブラリ `validate()`） |
| `verification/cli.py` | 出力ファイル検証の単体 CLI |
| `output/writer.py` | 出力ファイルへの書き込み（16 進形式） |
| `output/ascii_display.py` / `output/display.py` | ASCII 描画と表示モード用レジストリ |
| `mazegen.py` | 再利用可能な単一ファイルモジュール（仕様 VI の必須成果物） |
| `mazegen-1.0.0-*.whl` / `.tar.gz` | ビルド済みパッケージ（仕様 VI：`mazegen-*` をリポジトリ直下に配置） |
| `pyproject.toml` / `LICENSE.md` | パッケージのビルド元一式とライセンス（仕様 VI） |
| `config.txt` / `Makefile` / `setup.cfg` / `README.md` | 既定設定、ビルド、ドキュメント |

> **`mazegen-*`（whl/tar.gz）は仕様 VI「Code reusability requirements」で要求される必須提出物**です（ボーナスではありません）。`mazegen-*` の名前でリポジトリ直下に置き、評価時に再ビルドできるよう `pyproject.toml` などビルド元一式と `LICENSE.md` も同梱しています。使い方は「[再利用可能なコードと使用例](#再利用可能なコードと使用例)」を参照。
>
> なお、出力ファイルの構造検証は本プロジェクトの `verification/cli.py`（`python3 -m verification.cli <file>`）が担います。リポジトリ直下の `maze_analyzer.py` は**課題側が配布する分析スクリプト**であり、本プロジェクトの提出物（自作コード）ではありません。単独の `validator.py` というファイルは存在しません。

---

## 使い方（インストール／実行）（Instructions）

### 依存関係

実行に外部ライブラリは不要です（標準ライブラリのみ使用）。静的検査には `flake8`、`mypy` を使用します。

### セットアップと実行

```bash
# 開発ツールのインストール
make install

# デフォルトの config.txt を使って迷路を生成・表示
make run

# 別の設定ファイルを指定
make run CONFIG=my_config.txt

# デバッグ実行（pdb）
make debug

# 静的検査（flake8 + mypy）
make lint

# 静的検査（mypy を --strict で実行する厳格版）
make lint-strict
```

直接実行する場合:

```bash
python3 a_maze_ing.py config.txt
```

> 注記：`make install` は `./.venv` に隔離した仮想環境を構築し（`uv` を優先し、無ければ標準ライブラリの `venv` にフォールバック）、`run`／`debug`／`lint` はその環境を自動で使用します。Python のバージョンは `PY_VERSION`（既定 `3.12`）で指定できますが、あくまで優先指定であり、無い環境では利用可能な `python3` にフォールバックします。

> 注記：静的検査には 2 つのターゲットがあります。`make lint` は `flake8 .` と `mypy .`（`--warn-return-any --warn-unused-ignores --ignore-missing-imports --disallow-untyped-defs --check-untyped-defs` の複数オプション付き）を実行します。`make lint-strict` は `flake8 .` と `mypy . --strict` を実行する厳格版です。`setup.cfg` では `flake8` の `max-line-length = 100` を設定しており、docstring と型ヒントの可読性のために標準の 79 文字を意図的に緩和しています。

### 出力ファイルの検証

```bash
python3 -m verification.cli maze.txt
```

---

## 設定ファイルの構造と形式

1 行につき 1 つの `KEY=VALUE` を記述します。`#` で始まる行と空行は無視されます。

### 1 行の形式（許容される自由度）

読み込み（`validation/config.py` の `_read_pairs`）は寛容です。1 行ずつ次のように解釈されます。

| 項目 | 挙動 | 例 |
|------|------|-----|
| キーの大文字小文字 | 区別しない（内部で大文字化） | `width=20` ＝ `WIDTH=20` |
| キー・値の前後空白 | 除去する（タブ可） | `  WIDTH  =  20  ` → `WIDTH=20` |
| 行頭のインデント | 除去する（行全体を `strip`） | `\tSEED=42` |
| 値の中の `=` | 最初の `=` のみで分割（値に `=` を含められる） | `OUTPUT_FILE=a=b.txt` → 値 `a=b.txt` |
| コメント | 行頭（前後空白除去後）が `#` の行全体のみ | `# comment` |
| 行内コメント | **非対応**（`#` 以降も値の一部になる） | `WIDTH=20 # x` → 値 `20 # x`（後で不正値扱い） |
| 空行 | 無視 | |
| キーの重複 | 警告して後勝ち | 2 回目の `WIDTH` を採用 |
| BOM 付き UTF-8 | 対応（`utf-8-sig`） | 先頭キーも正しく読める |

### 不正時の扱い（フロー）

読み込み時点でファイルの途中終了はしません。まず全行を辞書に集約し、その後で使用可否を判定します。メッセージは **エラー（致命的＝終了）** と **警告（継続）** を使い分けます。

**エラー（`error:` 表示、最終的に終了）**

1. **形式が不正な行**（`KEY=VALUE` でない・キーが空）＝*パースエラー* → その場で行番号つきの `error:` を即座に表示してスキップ（読み込みは継続）。1 件でもあれば最終的に終了。
2. **必須キーの欠落／不正値** → 欠落と不正値は同種の致命的問題として**まとめて集約**し、`ConfigError` で一括表示して終了（最初の 1 件で止めない）。パースで落ちた行に対応する必須キーは「欠落」としてここにも現れます。

**警告（`warning:` 表示、継続）**

3. **任意キーの値が不正** → 警告を出し、デフォルト値にフォールバックして継続。
4. **未知のキー**（想定外・タイプミス）→ 警告を出して無視し、継続。
5. **キーの重複** → 警告を出して後勝ちで継続。
6. **`PERFECT=False` だが playable 成立に寸法が不足**（`(WIDTH-1)*(HEIGHT-1) < 2`、すなわち幅 1 のフレームや 2×2）→ 四隅・中央の通路化と独立ループ 2 本が幾何的に不可能なため、警告を出して `PERFECT=True`（完全迷路）にフォールバックして継続。

つまり生成を止めるのは 1.（パースエラー）と 2.（必須キーの問題）で、任意キー・未知キー・重複はすべて警告で継続します。

### 必須キー（`validation/config.py` で処理）

| キー | 説明 | 例 |
|------|------|-----|
| `WIDTH` | 迷路の幅（セル数、1 以上） | `WIDTH=25` |
| `HEIGHT` | 迷路の高さ（セル数、1 以上） | `HEIGHT=20` |
| `ENTRY` | 入口座標 `x,y` | `ENTRY=0,0` |
| `EXIT` | 出口座標 `x,y`（入口とは異なること） | `EXIT=24,19` |
| `OUTPUT_FILE` | 出力ファイル名 | `OUTPUT_FILE=maze.txt` |
| `PERFECT` | 完全迷路にするか（`True`／`False`） | `PERFECT=True` |

### 任意キー（`validation/options.py` で処理）

| キー | 説明 | デフォルト |
|------|------|--------|
| `SEED` | 乱数シード（再現性の確保） | なし（実行ごとにランダム） |
| `ALGORITHM` | 生成アルゴリズム名（現状 `backtracker` のみ） | `backtracker` |
| `DISPLAY` | 表示モード名（現状 `ascii` のみ） | `ascii` |
| `SIGN` | 埋め込む記号（使用可能な文字は `2` と `4` のみ） | `42` |

> `SIGN` にサイズ指定オプションはありません。字形は固定サイズ（1 文字あたり 3×5 セル、既定の桁間 1 セル）で、盤面に収まらなければ自動的に省略されます（「[プレイアブル成立条件と退化パターン](#プレイアブル成立条件と退化パターン)」の B 項参照）。描画できない文字を含む `SIGN` は警告のうえ既定の `42` にフォールバックします。

### config.txt の記述例

```ini
# 必須キー
WIDTH=25
HEIGHT=20
ENTRY=0,0
EXIT=24,19
OUTPUT_FILE=maze.txt
PERFECT=False

# 任意キー（省略可）
SEED=42
ALGORITHM=backtracker
DISPLAY=ascii
SIGN=42
```

必須キーの問題（欠落・不正値）は 1 つの `ConfigError` にまとめられ、分かりやすいメッセージで一括表示して終了します。形式が不正な行（パースエラー）は `error:` として即座に表示され、これも終了要因になります。任意キーの不正値・未知キー・キーの重複は警告のみで継続します（上記「不正時の扱い」を参照）。

### 値の形式（許容／棄却）

各キーの値として何を受理し、何を弾くかの一覧です（行の構文レベルの自由度は「[1 行の形式](#1-行の形式許容される自由度)」を参照）。

| キー | 許容する形式 | 弾く形式（結果） |
|------|------|------|
| `WIDTH` / `HEIGHT` | 1 以上の整数（例：`25`、`+25`） | 非整数（`abc`、`2.5`）・0 以下 → **エラーで終了** |
| `ENTRY` / `EXIT` | `x,y`（カンマ区切り 2 要素・各整数・範囲内 `0<=x<WIDTH`、`0<=y<HEIGHT`）。要素前後の空白可 | 要素数が 2 でない（`0`、`0,0,0`）・非整数（`a,b`）・範囲外・`ENTRY==EXIT` → **エラーで終了** |
| `PERFECT` | `true`／`false`／`1`／`0`／`yes`／`no`（大文字小文字不問） | それ以外（`T`、`on` など）→ **エラーで終了** |
| `SEED` | 整数 | 非整数 → **警告して既定（ランダム）にフォールバック** |
| `ALGORITHM` / `DISPLAY` | 登録済みの名前（`backtracker`／`ascii`） | 未登録名 → **警告して既定にフォールバック** |
| `SIGN` | `2` と `4` のみからなる文字列 | 描画不可文字を含む → **警告して既定 `42` にフォールバック** |

要点：**必須キーの不正値は終了**、**任意キーの不正値は警告して既定へフォールバック**して継続します。

---

## 出力ファイル形式（仕様 IV.5）

- 各セルは大文字の 16 進数 1 桁で表します。閉じた壁はビットで符号化されます：`bit0=北、bit1=東、bit2=南、bit3=西`（そのビットが 1 なら壁が閉じている）。
- 1 行が迷路の 1 行分のセルに対応します。

**符号化の具体例**（値 = 北 + 東×2 + 南×4 + 西×8）：

| 16進 | 2進 (西南東北) | 閉じている壁 | 意味 |
|---|---|---|---|
| `F` | `1111` | 北・東・南・西すべて | 四方が壁（例：「42」セルや初期状態） |
| `0` | `0000` | なし | 四方が開通 |
| `9` | `1001` | 北 (bit0) ＋ 西 (bit3) | 北西が壁、東と南が開通 |
| `5` | `0101` | 北 (bit0) ＋ 南 (bit2) | 上下が壁の横向き通路 |
| `A` | `1010` | 東 (bit1) ＋ 西 (bit3) | 左右が壁の縦向き通路 |

例：セル値 `9`（=`0b1001`）は bit0（北）と bit3（西）が立つので、北と西に壁があり、東と南へは通行できます。
- 空行を 1 行挟んだ後、入口 `x,y`、出口 `x,y`、最短経路（`N`／`E`／`S`／`W` を連結した文字列）の計 3 行を記述します。
- すべての行は `\n` で終わります。

---

## 使用アルゴリズムと採用理由

### 生成：再帰的バックトラッカー（反復実装）

すべてのセルが壁で閉じた状態から始め、深さ優先でランダムに通路を掘り進め、行き止まりではスタックを戻ります。全セルを 1 本の木として接続するため（**全域木**）、`PERFECT=True` の条件、すなわち任意の 2 点間に経路がちょうど 1 つ存在することを自然に満たします。

**採用理由:**

- 完全迷路を保証できます（DFS 木＝全域木）。
- 実装がシンプルで、乱数源を `random.Random(seed)` の 1 か所に集約できるため、再現性が高くなります。
- 明示的なスタックを使う反復実装のため、大きな迷路でも Python の再帰上限に達しません。
- 「42」用に予約したセルは掘らないだけで、記号を通路の中に保てます。

アルゴリズムは `ALGORITHM` キーで選択できます。**実装済みは `backtracker` のみ**です。

> 注記：`generation/generator.py` の `ALGORITHMS` レジストリは、将来 Prim 法や Kruskal 法などを登録すれば選択肢を増やせる拡張点として用意してあります（ボーナス向けの設計余地であり、現時点で選択できるのは `backtracker` だけです）。

### プレイアブル盤面（`PERFECT=False`、仕様 IV.4, v2.2）

バックトラッカーが全域木を作った後、`braiding/braiding.py` が 3 フェーズで盤面を整形します：(1) 行き止まりの削減、(2) 四隅と中央の通路化（開口 2 つ以上）、(3) 独立ループ 2 本以上の保証。いずれの壁開放も 3×3 の開放領域を作らず、「42」予約セルには触れません。

プレイアブル盤面が成立するには `(WIDTH-1)*(HEIGHT-1) >= 2` が必要です（四隅・中央を開口 2 つ以上にでき、独立ループを 2 本張れる最小条件）。これを満たさない寸法（幅 1 のフレーム、または 2×2）は seed に依らず必ず未達になるため、入力時に警告のうえ完全迷路にフォールバックします。なお「42」サインがプレイアブル要件を壊す配置しか取れない場合は、サインの配置を探索したうえで置けなければサインを省略します。

四隅と中央のセルは `(0,0)`／`(WIDTH-1,0)`／`(0,HEIGHT-1)`／`(WIDTH-1,HEIGHT-1)` と、中央 `(WIDTH//2, HEIGHT//2)` です（整数除算）。幅・高さが偶数のときは中央 2 セルのうち大きい添字側（右／下寄り）が選ばれます（例：`WIDTH=20` なら `x=10`）。この定義は `core/maze.py` の `playable_corridors` を単一の真実として生成側・検証側が共有するため、両者で食い違いません。

#### プレイアブル成立条件と退化パターン

ファズ試験（ランダム多数）と敵対的レビューで洗い出した、把握すべき成立／退化パターンです。

**成立マップ（実測・seed 非依存）** — O=全 seed 成立 ／ X=不成立 ／ -=入口出口同一で不可

```
   H\W   1   2   3   4   5 …
    1    -   X   X   X   X
    2    X   X   O   O   O
    3    X   O   O   O   O
    …    X   O   O   O   O
```

braiding は幾何的に可能な限り必ず 2 本以上のループを達成する確定的挙動のため、「seed 次第」の中間状態はありません。最小成立は 2×3／3×2 です。

**A. 不成立領域とフォールバック**

| パターン | 状態 | 挙動 |
|---|---|---|
| 1 マス幅（min(W,H)=1） | 常に不成立（ループ 0 が原理的に不可能） | 警告のうえ PERFECT にフォールバック |
| 2×2 | 不成立（ループ 1 本止まり） | 同上 |
| 上記以外で W,H≥2 | 成立（(W−1)(H−1)≥2） | プレイアブル生成 |

**B. サイン「42」**（描画に 7×5 が必要）

- 盤面が 7×5 未満 → サイン省略（`does not fit`、非致命）
- 入口出口・四隅中央がサイン域を塞ぐ → 配置を探索し、置けなければ省略（`cannot place`）
- `PERFECT=False` の小盤面 → 四隅中央の通路確保のためサインはほぼ省略

**C. 入口出口**

- 内部・隣接・同一行／列 → 可（成立域なら）
- 範囲外・`ENTRY==EXIT` → config エラーで拒否（exit 1）

**D. 設定書式の退化** — 重複キー（後勝ち）／小文字キー／余分な空白／未知キー（無視）／コメント・空行はすべて警告付きで受理します（詳細は「[不正時の扱い（フロー）](#不正時の扱いフロー)」を参照）。

### 求解：BFS（幅優先探索）

入口および出口から各セルまでの最短距離を計算し、最短経路とその経路上の全セルを取得します。BFS を用いるため、不完全迷路でも最短経路が保証されます。

---

## 生成後の検証（`verification/verifier.py` + `verification/cli.py`)

専用バリデーターは、生成した迷路が仕様 IV.4 の条件を満たすことを確認します。これは設定ファイルの**入力検証**（`validation/`）とは別の、組み上がった迷路の**構造検証**です。

- 入口と出口が範囲内にあり、互いに異なること
- 外周セルの外向きの壁が閉じていること
- 隣接セル間で共有する壁に矛盾がないこと
- 「42」（完全に閉じた `0xF` セル）を除くすべてのセルが連結していること
- 完全に開いた 3×3 領域がないこと（通路幅は最大 2 セル）
- `PERFECT` の場合、経路がちょうど 1 つであること（ループがないこと）
- `PERFECT=False` の場合、四隅と中央が開いた通路であり、独立ループが 2 本以上、行き止まりが僅少であること
- 付記された最短経路が実際に通行可能で、かつ最短であること

メインプログラムは生成直後にこの検証を実行し、問題があれば警告します。ライブラリ（`verification.verifier.validate()`）としても CLI（`python3 -m verification.cli <file>`）としても利用できます。

---

## 再利用可能なコードと使用例

パイプラインは役割ごとのパッケージに分割されており、各モジュールは `a_maze_ing.py` に依存しないため単独でインポートできます。

```python
import random
from core.maze import Maze, solve, solution_cells
from generation.backtracker import generate_backtracker
from generation.initializer import reserved_cells

# 「42」用セルを予約して迷路を生成
reserved = reserved_cells(25, 20)
maze = generate_backtracker(25, 20, reserved, random.Random(42), start=(0, 0))

# 解（最短経路）を取得
path = solve(maze, (0, 0), (24, 19))           # 例: "EESS..."
cells = solution_cells(maze, (0, 0), (24, 19)) # 経路上にあるセルの集合

# 壁コードにアクセス（bit0=N、bit1=E、bit2=S、bit3=W、閉じている場合は 1）
code = maze.cells[0][0]
```

主なパッケージ:

- `core/maze.py`：壁の表現（`Maze`）、`bfs_distances`、`solve`、`solution_cells`
- `core/metrics.py`：`count_loops`、`count_dead_ends`（braiding と verification が共有）
- `generation/initializer.py`：初期マップの生成と「42」記号の配置
- `generation/backtracker.py` / `generation/generator.py`：生成アルゴリズムと選択用レジストリ
- `braiding/braiding.py`：不完全迷路（プレイアブル盤面）への変換
- `output/writer.py` / `output/ascii_display.py` / `output/display.py`：出力と表示
- `verification/verifier.py` / `verification/cli.py`：条件検証（ライブラリ／CLI）

ジェネレーターは、自己完結した単一ファイルの `pip` パッケージ（`mazegen.py`）としても配布されています。ビルド済み成果物（`mazegen-1.0.0-py3-none-any.whl` と `mazegen-1.0.0.tar.gz`）はリポジトリ直下にあります。MIT ライセンス（`LICENSE.md`）で公開しており、後続の 42 プロジェクトでの再利用が明示的に許可されています。

```python
from mazegen import MazeGenerator

gen = MazeGenerator(20, 15, seed=1, perfect=False).generate()
grid = gen.grid                       # 4 ビットの壁コードからなる 2 次元配列
path = gen.solution((0, 0), (19, 14)) # 最短経路 "N/E/S/W"
```

---

## チームとプロジェクト管理

- **メンバーと担当:**
  - **naarai**：コア機能と生成。`core/maze.py`（壁モデル、BFS／求解）、`generation/backtracker.py`／`braiding/braiding.py`（不完全迷路用ボード）、および再利用可能な `mazegen` パッケージを担当。
  - **ksadayas**：I/O と検証。`validation/config.py`／`validation/options.py`／`core/errors.py`（設定解析）、`output/writer.py`／`output/ascii_display.py`、`verification/verifier.py`（ASCII 表示と対話）、テスト、ドキュメントを担当。
- **計画と発展:** 「求解 → 初期化（42）→ 生成 → 出力 → 表示 → 検証」の順で段階的に構築し、各機能を小さな単位でコミットしました。
- **うまくいった点:** 壁の表現を 1 か所（`core/maze.py`）に集約したことで、生成・表示・出力・検証の不整合を防げました。例外を致命的／非致命的に分けたことで、エラーの判別も容易になりました。`PERFECT=False` のボードは仕様 v2.2 のプレイアブル要件（四隅・中央の通路化、独立ループ 2 本以上）を満たすうえ、**サイン包囲を除く真の行き止まりが 0**（`maze_analyzer.py` が `--max-dead-ends 0` で `bonus-grade (perfectly braided)` と判定）で、仕様 VIII の「行き止まりなし」ボーナスを達成しています。
- **改善できる点:** 実装済みの生成アルゴリズムは再帰的バックトラッカーのみです（`ALGORITHMS` レジストリはボーナスとして Prim 法／Kruskal 法を追加できるよう準備済み）。また、表示は ASCII のみで、MLX による表示は今後の課題です。

---

## 参考資料（参照先／AI 利用）（Resources）

- 迷路生成アルゴリズム全般（再帰的バックトラッカー／Prim 法／Kruskal 法）：Jamis Buck, *"Maze Generation Algorithms"* — <https://weblog.jamisbuck.org/2011/2/7/maze-generation-algorithm-recap>
- 迷路生成の概説：Wikipedia, *"Maze generation algorithm"* — <https://en.wikipedia.org/wiki/Maze_generation_algorithm>
- グラフ理論における全域木（完全迷路との対応）：Wikipedia, *"Spanning tree"* — <https://en.wikipedia.org/wiki/Spanning_tree>
- 独立ループ数（サイクルランク＝`edges - vertices + 1`）：Wikipedia, *"Circuit rank"* — <https://en.wikipedia.org/wiki/Circuit_rank>
- 最短経路探索（BFS）：Wikipedia, *"Breadth-first search"* — <https://en.wikipedia.org/wiki/Breadth-first_search>
- 「42」記号の正確な形状は、課題 PDF（`a_maze_ing.pdf`）の図から取得

**AI の利用:** 設計のブレインストーミング、各モジュールの docstring・型注釈付き実装、テスト作成、PDF からの「42」形状の抽出（画像解析）、README の推敲に AI を利用しました。
